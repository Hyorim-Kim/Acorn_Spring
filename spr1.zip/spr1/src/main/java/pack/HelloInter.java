package pack;

public interface HelloInter {
   void sayHello(String name);
}